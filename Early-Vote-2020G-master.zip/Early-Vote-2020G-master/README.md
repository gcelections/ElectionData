# Early-Vote-2020G

Web tracker for 2020 general election early vote (mail and in-person) activity
